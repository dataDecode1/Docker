
-- create dipuser, dip database and 6 tables with below schema 

CREATE DATABASE IF NOT EXISTS dip;

create user 'dipuser'@'%' identified WITH mysql_native_password by 'pwd4Dip@Local!';
ALTER USER 'dipuser'@'%' IDENTIFIED WITH mysql_native_password BY 'pwd4Dip@Local!';

GRANT ALL PRIVILEGES ON dip.* to 'dipuser'@'%';

FLUSH PRIVILEGES;

CREATE TABLE dip.ext_table
(
   file_id          int(11),
   file_name        varchar(255),
   ext_table_name   varchar(255),
   delim            varchar(5),
   serde            varchar(5),
   input_path       varchar(1024),
   hive_db          varchar(255),
   header_line_count  int(10) DEFAULT 0,
   footer_line_count  int(10) DEFAULT 0,
   encoding         varchar(45) DEFAULT NULL,
   db_connect        varchar(255) DEFAULT NULL,
   db_type           varchar(255) DEFAULT NULL,
   username          varchar(255) DEFAULT NULL,
   db_rdbms          varchar(255) DEFAULT NULL,
   db_table          varchar(255) DEFAULT NULL,
   split_by_field    varchar(255) DEFAULT NULL,
   where_clause      varchar(255) DEFAULT NULL,
   mappers          varchar(255) DEFAULT NULL,
   masternode_host  varchar(255) DEFAULT NULL,
   cassandra_keyspace varchar(255) DEFAULT NULL,
   cassandra_table  varchar(255) DEFAULT NULL
);
ALTER TABLE dip.ext_table ADD PRIMARY KEY (file_id);

--  TABLE ext_table_def
CREATE TABLE dip.ext_table_def
(
   file_id           int(11),
   col_name          varchar(255),
   target_col_name   varchar(255),
   hive_trans_logic  varchar(5000) DEFAULT '',
   col_desc          varchar(5000),
   col_order         int(11),
   d_type            varchar(45),
   cdc_key           int(11) DEFAULT 0,
   cdc_compare       int(11) DEFAULT 0,
   start             int(10),
   len               int(10),
   mask_indicator	 int(11) DEFAULT 0
);
ALTER TABLE dip.ext_table_def ADD PRIMARY KEY (file_id, col_order);

--  TABLE target_table
CREATE TABLE dip.target_table
(
   table_id          int(11),
   table_name        varchar(255),
   hive_db           varchar(255),
   output_path       varchar(1000) DEFAULT NULL,
   delim             varchar(5) DEFAULT NULL,
   db_connect        varchar(255) DEFAULT NULL,
   db_type           varchar(255) DEFAULT NULL,
   username          varchar(255) DEFAULT NULL,
   db_rdbms          varchar(255) DEFAULT NULL,
   db_table          varchar(255) DEFAULT NULL,
   mappers           varchar(255) DEFAULT NULL
);
ALTER TABLE dip.target_table ADD PRIMARY KEY (table_id);

--  TABLE target_table_def
CREATE TABLE dip.target_table_def
(
   table_id      int(11),
   col_name      varchar(255),
   target_col_name   varchar(255),
   col_desc      varchar(255),
   col_order     int(11),
   d_type        varchar(45),
   cdc_key       int(11) DEFAULT 0,
   cdc_compare   int(11) DEFAULT 0
);
ALTER TABLE dip.target_table_def ADD PRIMARY KEY (table_id, col_order);

CREATE TABLE dip.batch_id_control (
  file_id int(11) DEFAULT NULL,
  current_batch_id int(11) DEFAULT NULL,
  last_batch_id int(11) DEFAULT NULL,
  incr_value varchar(10) DEFAULT NULL
);

CREATE TABLE dip.job_parameters (

  table_id int(11) DEFAULT NULL,
  param_name varchar(1024) DEFAULT NULL,
  param_value varchar(1024) DEFAULT NULL,
  exec_order int(11) DEFAULT NULL
);
