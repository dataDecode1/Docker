# DIP Mysql Metastore

- Pull the repo, cd to folder where Dockerfile is 
- Run below commands to install, start mysql server with dip pre-defined table schemas from mysql_setup.sql

## Mysql Docker Image build  
```docker build --rm=true -t mysql-docker:8.0 .```

## Run container
```docker run -d -p 3306:3306 --name mysql-server -e MYSQL_ROOT_PASSWORD=pwd4DipLocal mysql-docker:8.0```

## Execute sql script that creates dip tables
```docker exec container_id mysql -h localhost -P 3306 --protocol=tcp --user=root --password="pwd4DipLocal" -e "source /dipuser/mysql_setup.sql"```

### Note: 
- ```docker ps```gives container_id in above exec command.
- We cannot run sh / sql script before a container is up and running. 

### Reference
- https://severalnines.com/blog/mysql-docker-building-container-image
- https://jsw.ibm.com/browse/DIPDACH-72
