/*
    Author:  Tom Graepel (516) 672-1483
    Date:  2018-03-09
    Version 1.1
    Changes:
        1.1  Added a trim on the val to allow "    47" to be a valid number
        removed extraneous printing of "Long: XX"
        added commented code for the apache org dependencies and reordered comments
    Basic Inputs
        val = the string to be evaluated
        datatype = the hive datatype to be evaluated
        returnCheck = CHECK_NULL or NO_CHECK_NULL
    Basic Outputs
        0 = Pass
        1 = Fail
        any other number is testing and should not be ther
    Basic TDQ Flow
    1)  Set up the values for the allowable datatypes into Sets
    2)  Start the checks
        2a)  IF the NULL CHECK is set and the value passed in is null or blank ==> FAIL
        2b)  ELSEIF the value checked is null or blank ==> PASS
        2c)  ELSEIF the datatype checked is not valid ==> FAIL
        2d)  ELSEIF the datatype checked is STRING, CHAR, VARCHAR ==> PASS
        2e)  ELSE ==> GOTO NEXT STEP 3
    3)  Evaluate remaining data types:  Numerics/Integers and Dates/Timestamps
        3a) Check Numerics and Integers
            3a.1)  Determine if input value is integer, decimal or neither through regular expression
            3a.2) IF the length of the number is too large to handle ==> FAIL
            3a.3) ELSEIF the datatype is an Integer (Big, Tiny, etc) check that it falls within the appropriate +/- range ==> FAIL if it doesn't
            3a.4) ELSEIF the datatype is a Decimal/Numeric and that the regular expression detects validity ==> PASS
            3a.5) ELSE not valid if it gets into this code branch ==> FAIL
        3b) Check Dates and Timestamps
            3b.1) Set up variables for PRECHECK:  counts of dashes, slashes, colons, spaces, letters, numbers, and length of the string
            3b.2) Perform precheck against variables ==> FAIL
            3b.3) If precheck succeeds then set translate the date to a standard format YYYY-MM-DD
            3b.4) Check the year against a valid range:  If bad ==> FAIL
            3b.5) If year is ok check the month against a valid range:  If bad ==> FAIL
            3b.6) If the month is ok check the day against a valid range to include leap year:  If bad ==> FAIL
            3b.7) If the datatype is a TIMESTAMP check the values against a valid list of Hours 00-23 Minutes and Seconds 00-59
        3c) Should never get in here but if it does ==> FAIL
*/


package com.daas;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

// UNCOMMENT THE BELOW LINES WHEN COMPILING JAR
import org.apache.hadoop.hive.ql.exec.UDF;
public class SimpleUDF extends UDF {

// COMMENT THIS LINE OUT WHEN COMPILING
//public class SimpleUDF {
    public int evaluate(String val, String datatype, String returnCheck ) {
        int rtnValue = 0;
        Set validStringTypes = new HashSet();
        Set validIntTypes = new HashSet();
        Set validNumericTypes = new HashSet();
        Set validDateTypes = new HashSet();
        Set validTypes = new HashSet();

        validIntTypes.add("TINYINT");
        validIntTypes.add("SMALLINT");
        validIntTypes.add("INT");
        validIntTypes.add("INTEGER");
        validIntTypes.add("BIGINT");
        validNumericTypes.add("FLOAT");
        validNumericTypes.add("DOUBLE");
        validNumericTypes.add("DECIMAL");
        validNumericTypes.add("NUMERIC");
        validDateTypes.add("TIMESTAMP");
        validDateTypes.add("DATE");
        validStringTypes.add("STRING");
        validStringTypes.add("VARCHAR");
        validStringTypes.add("CHAR");
        validTypes.addAll(validStringTypes);
        validTypes.addAll(validIntTypes);
        validTypes.addAll(validDateTypes);
        validTypes.addAll(validNumericTypes);

        if  ((val == null || val.trim().equals("")   ) && (returnCheck.equals("CHECK_NULL") )) {
            // check for nulls / blanks
            rtnValue = 1;
        }
        else if ((val == null) || val.trim().equals("") ) {
            // Nulls and Blanks are automatically ok
            rtnValue = 0;
        }
        else if ( ! validTypes.contains(datatype) ){
            // Bad Data types automatically get a failure return code
            rtnValue = 1;
        }
        else if (validStringTypes.contains(datatype)){
            // STRINGS CHAR AND VARCHAR DO NOT GET CHECKED
            rtnValue = 0;
        }
        else
        {
            val = val.trim();

            if (validNumericTypes.contains(datatype) || validIntTypes.contains(datatype))
            {
                String regexInt = "^[-+]?[0-9]+$";
                String regexDec = "^[-+]?[0-9]+\\.[0-9]+";

                boolean amIInt = val.matches(regexInt);
                boolean amIDecimal = val.matches(regexDec);

                if (datatype.equals("BIGINT") && amIInt)
                {
                    String stringNumbersOnly = val.replaceAll("[^0-9]","");
                    if ((stringNumbersOnly.length() > 0 ) && (stringNumbersOnly.length() < 19))
                    {
                        rtnValue = 0;
                    }
                    else if ( stringNumbersOnly.length() == 19)
                    {
                        String topValue = "9223372036854775808";
                        rtnValue = (topValue.compareTo(stringNumbersOnly) ==  -1) ? 0 : 1;
                    }
                    else
                    {
                        rtnValue = 1;
                    }
                }
                else if ( amIInt && validIntTypes.contains(datatype) && val.trim().length() > 12 )
                {
                    // Avoid the casting issue for integers to Long that are too large
                    rtnValue = 1;
                }
                else if ((amIInt) && (validNumericTypes.contains(datatype) || validIntTypes.contains(datatype)))
                {
                    Long longVal = Long.valueOf(val);
                    if (validNumericTypes.contains(datatype)) { rtnValue = 0; }
                    else if (datatype.equals("TINYINT")  && longVal>= -128L         && longVal <= 127L) {rtnValue = 0;}
                    else if (datatype.equals("SMALLINT") && longVal>= -32768L       && longVal <= 32767L) {rtnValue = 0;}
                    else if (datatype.startsWith("INT")  && longVal>= -2147483648L  && longVal <= 2147483647L) {rtnValue = 0;}
                    //else if (datatype.equals("BIGINT")   && longVal>= -9223372036854775808L && longVal <= 9223372036854775807L) {rtnValue = 0;}
                    else { rtnValue = 1; }
                }
                else if ( amIDecimal && validNumericTypes.contains(datatype) ) { rtnValue = 0; }
                else { rtnValue = 1; }
            } //NUMERIC AND INTS
            else if (validDateTypes.contains(datatype))
            {
                String trimVal = val.trim().toUpperCase();
                int lenVal = trimVal.length();
                int countDashes = lenVal - trimVal.replace("-", "").length();
                int countColons = lenVal - trimVal.replace(":", "").length();
                int countSpaces = lenVal - trimVal.replace(" ", "").length();
                int countSlashes = lenVal - trimVal.replace("/", "").length();
                int countNumbers = lenVal - trimVal.replaceAll("[0-9]", "").length();
                int countLetters = lenVal - trimVal.replaceAll("[A-Z]", "").length();

                if (
                        datatype.equals("DATE") && !(lenVal == 10 || lenVal == 9  )
                    || (datatype.equals("DATE") && lenVal==10 && countNumbers != 8 )
                    || (datatype.equals("DATE") && lenVal==9 && countNumbers != 6 && countLetters !=3 )
                    || ( datatype.equals("TIMESTAMP") && lenVal != 19)
                    || ( datatype.equals("TIMESTAMP") && ! (countColons == 2 && countSpaces == 1 && countDashes == 2))
                    || ( datatype.equals("DATE") && lenVal == 10 &&  ! (countDashes == 2 || countSlashes == 2))
                   )
                {
                    rtnValue = 1;
                }
                else {
                    String xlateDate = trimVal;
                    if (lenVal == 9)
                    {
                        Map<String, String> validShortMonth = new HashMap<String, String>();
                        validShortMonth.put("JAN","01");
                        validShortMonth.put("FEB","02");
                        validShortMonth.put("MAR","03");
                        validShortMonth.put("APR","04");
                        validShortMonth.put("MAY","05");
                        validShortMonth.put("JUN","06");
                        validShortMonth.put("JUL","07");
                        validShortMonth.put("AUG","08");
                        validShortMonth.put("SEP","09");
                        validShortMonth.put("OCT","10");
                        validShortMonth.put("NOV","11");
                        validShortMonth.put("DEC","12");
                        if(validShortMonth.containsKey(xlateDate.substring(2,5))){
                            xlateDate = xlateDate.substring(5,9) + "-" + validShortMonth.get(xlateDate.substring(2,5)) + "-" + xlateDate.substring(0,2) ;
                        }
                        else
                        {
                            xlateDate = "XXXX-XX-XX";
                        }

                   }
                   else if (countSlashes == 2 && lenVal == 10 ) {
                        xlateDate = xlateDate.substring(6,10) + "-" + xlateDate.substring(0,2) + "-" + xlateDate.substring(3,5);
                   }
                   Set validYears = new HashSet();
                    String substrYear = xlateDate.substring(0, 4);
                    for (int i = 1900; i <= 2100 ; i++)
                    { validYears.add(String.format("%4d", i) ); }
                    if (validYears.contains(substrYear))
                    {
                        Set validMonths = new HashSet();
                        String substrMonth = xlateDate.substring(5, 7);
                        for (int i = 1; i < 13 ; i++)
                        { validMonths.add(String.format("%02d", i) ); }

                        if (validMonths.contains(substrMonth))
                        {
                            Set validDays = new HashSet();
                            String monthsLessThan31 = "02 04 06 09 11";
                            String substrDay = xlateDate.substring(8, 10);

                            for (int i = 1; i < 32 ; i++)

                            {
                                if (substrMonth.equals("02") && i > 28 )
                                {
                                    if (i> 29){
                                        //ADD NO DAY
                                    }
                                    else {
                                        //I = 29 Check for leap year
                                        int year = Integer.parseInt(substrYear);
                                        boolean isLeapYear = ((year % 4 == 0) && ( year % 100 != 0 ) || (year % 400 == 0));
                                        if (isLeapYear)
                                        { validDays.add(String.format("%02d", i));}
                                    }
                                }
                                else if ((monthsLessThan31.contains(substrMonth)) && (i == 31)) { }
                                else { validDays.add(String.format("%02d", i)); }
                            }
                            if (! validDays.contains(substrDay)) { rtnValue = 1; }
                        }
                        else { rtnValue = 1; }
                    }
                    else { rtnValue = 1; }

                    if ( (rtnValue == 0 ) && (  (datatype.equals("TIMESTAMP"))))
                    {
                        Set validMinutesSeconds = new HashSet();
                        Set validHours = new HashSet();

                        for (int i = 0; i < 60 ; i++)
                        { validMinutesSeconds.add(String.format("%02d", i) ); }
                        for (int i = 0; i < 24 ; i++)
                        { validHours.add(String.format("%02d", i) ); }

                        String substrHours = val.trim().substring(11, 13);
                        String substrMinutes = val.trim().substring(14, 16);
                        String substrSeconds = val.trim().substring(17, 19);
                        if (
                                validHours.contains(substrHours) &&
                                validMinutesSeconds.contains(substrMinutes) &&
                                validMinutesSeconds.contains(substrSeconds)
                           )
                        {
                            rtnValue = 0;
                        }
                        else
                        {
                            rtnValue = 1;
                        }
                    }
                } // ELSE PORTION OF DATES AND TIMESTAMPS
            } // DATES AND TIMESTAMPS
            else
            { rtnValue = 1;}
        }
        return rtnValue;
    }
}
