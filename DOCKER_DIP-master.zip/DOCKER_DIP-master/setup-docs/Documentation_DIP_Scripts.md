<h2>Summary</h2>
<ul>
  <li>There is only a limited amount of external libraries that have to be installed: <i>mysql, jpype, jaydebeapi, impala,  
   pyspark (, optparse,subprocess) </i></li>
  <li>All python scripts depend on the local <i>ingestUtil</i> module</li>
  <li>The following environment variables are in use <i>DAAS_INGEST_CONFIG, INGEST_DEBUG_MODE, SPARK_MAJOR_VERSION</i></li>
  <li><i>Sqoop, hive, hdfs</i> needs to be installed on the machine</li>
  <li> All scripts just log the steps they perform and technical errors that appear like failing to connect to a database </li>
  <li> A lot code duplication </li>
</ul>


<h2> Detailed analysis of scripts </h2>


| File Name  |  Functionality| Logging | Dependencies | 
|---|---|---|---|
| append_2_table_jdbc.py  | Connects to Metadata reporsitory, gets Hive database locations of the external and target tables, publishes data from external table | `INFO` logs for the steps of the script, such as initializing environment, showing parsed parameters, DB connections. A couple of `ERROR` logs as well. However the `ERROR` logs are general, usually part of a `try...catch` statement and do not really give any information regarding to what has gone wrong  | <b> Libraries </b> mysql, ingestionUtil, impala, optparse <br><b>Tables</b> ext_table, target_table, ext_table_def  | 
| append_2_table.py  |  Collects metadata for a particular `file_id` from the MySql DB, selects Hive database locations of the external an target tables, builds `INSERT` SQL and generates `ALTER TABLE` DDL to drop partition if exists | `INFO` logs for the steps of the script, such as initializing environment, showing parsed parameters, DB connections. A couple of `ERROR` logs as well. However the `ERROR` logs are general, usually part of a `try...catch` statement and do not really give any information regarding to what has gone wrong   |  <b> Libraries </b> mysql, ingestionUtil, impala, optparse <br><b>Tables</b> ext_table, target_table, ext_table_def  | 
| append_2_tdq.py  |  Publishes data from external table to Hive | `INFO` logs for the steps of the script, such as initializing environment, showing parsed parameters, DB connections. A couple of `ERROR` logs as well. However the `ERROR` logs are general, usually part of a `try...catch` statement and do not really give any information regarding to what has gone wrong   |  <b> Libraries </b> mysql, ingestionUtil, impala, optparse <br><b>Tables</b> ext_table, target_table, ext_table_def |
| batch_append_<br>2_table.py  |  Calls `append_2_table.py` for multiple files | Writes logs regarding processing steps in a log file, using a Logging class  |  <b> Libraries </b> mysql, ingestionUtil, impala, subprocess <br><b>Tables</b> ext_table |
| batch_copy_2_hdfs.py  |  Calls `copy_2_hdfs.py` for multiple files | Writes logs regarding processing steps in a log file, using a Logging class  |  <b> Libraries </b> mysql, ingestionUtil, impala, subprocess <br><b>Tables</b> ext_table |
| batch_create_<br>ext_table_serde.py  |  Calls `create_ext_table_serde.py` for multiple files| Writes logs regarding processing steps in a log file, using a Logging class  |  <b> Libraries </b> mysql, ingestionUtil, impala, subprocess <br><b>Tables</b> ext_table |
| batch_inbound_2_archive.py  |  Move data to archive on the edge node and on HDFS| Writes logs regarding processing steps in a log file, using a Logging class  |  <b> Libraries </b> mysql, ingestionUtil, impala, subprocess <br><b>Tables</b> ext_table |
| batch_publish_metadata.py  |  Calls `publish_metadata.py` once for ext_table and once for ext_table_def| Prints, no logs  |  <b> Libraries </b> subprocess <br><b>Tables</b> ext_table, ext_table_def |
| batch_replace_2_table.py  |  Calls `replace_2_table.py` for multiple files| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> mysql, ingestionUtil, impala, subprocess <br><b>Tables</b> ext_table|
| cassandra_2_hdfs.py  |  Reads cassandra Keyspace, using Spark and writes to HDFS| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil, subprocess, optparse, pyspark <br><b>Tables</b> ext_table|
| cdc_2_table.py  |  Publishes cdc data to Hive| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil, optparse, impala, mysql <br><b>Tables</b> ext_table, ext_table_def, target_table, target_table_def|
| check_pk.py  |  Checks for duplicated data in Hive, based on cdc key| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> mysql, ConfigParser, impala, ingestionUtil <br><b>Tables</b> ext_table|
| check_rows.py  |  Compares record count between source file and header file| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> subprocess, ingestionUtil <br><b>Tables</b> |
| check_table_rows.py  |  Compares row count between external table and source dataset| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> subprocess, ingestionUtil, mysql, ConfigParser <br><b>Tables</b> ext_table|
| copy_2_hdfs.py  |  Copies data from local file into HDFS | Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil <br><b>Tables</b> ext_table|
| create_ext_metadata.py  |  Creates external metadata table | Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil, mysql, impala, subprocess <br><b>Tables</b> ext_table, ext_table_def|
| create_ext_table_<br>csv_serde.py  |  Connect to Metadata Repository and Build Create Table DDL | Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil, mysql, impala, subprocess, pyhs2, ConfigParser <br><b>Tables</b> ext_table, ext_table_def|
| create_ext_table_serde.py  |  Connect to Metadata Repository and Build Create Table DDL | Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil, mysql, impala, subprocess<br><b>Tables</b> ext_table, ext_table_def|
| create_ext_table_<br>string_comment.py  |  Connect to Metadata Repository and Build Create Table DDL, including string comment | Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil, mysql, impala, subprocess<br><b>Tables</b> ext_table, ext_table_def|
| create_ext_table_string.py  |  Connect to Metadata Repository and Build Create Table DDL| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil, mysql, impala, subprocess<br><b>Tables</b> ext_table, ext_table_def|
| create_ext_table.py  |  Creates external table in Hive| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil, mysql, impala, subprocess<br><b>Tables</b> ext_table|
| create_hbase_table.py  |  Creats external table in HBase| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil<br><b>Tables</b> ext_table, external_table_def|
| create_table_as.py  |  Creates external table in Hive| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil, mysql, impala, optparse<br><b>Tables</b> ext_table, external_table_def, target_table, target_table_def|
| create_tar_table.py  |  Creates target table in Hive| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil, mysql, impala<br><b>Tables</b> target_table, target_table_def|
| create_tdq_view.py  |  Creates TDQ vies. File is very large and hard to understand what is going on exactly | Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> json<br><b>Tables</b> target_table, target_table_def|
| create_table_as.py  |  Creates external table in Hive| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil, mysql, impala, optparse<br><b>Tables</b> ext_table, external_table_def, target_table, target_table_def|
| create_view.py  |  Creates table view in Hive| Writes logs regarding processing steps in a log file, using a Logging class   |  <b> Libraries </b> ingestionUtil, mysql, impala, subprocess<br><b>Tables</b> ext_table, external_table_def|
| curation_demo.sh  |  Calls multiple py scripts one after the other| Writes logs regarding processing steps in a log file |  <b> Libraries </b> <br><b>Tables</b> |
| data_obfuscation.py  |  Basically takes a data file as input which content is then masked/obfuscated by the parameters in the meta database. Result is written to another file. On technical level it seems to be an xor operation | Only logs the steps of the script|  <b> Libraries </b> mysql, ingestionUtil <br><b>Tables</b> ext_table, ext_table_def| 
| delim_count.py  |  Checks for the first twenty lines in a "csv" file if they have the expected number of columns and if all are non empty  | Logs the result of the checks to a file as well as the steps|  <b> Libraries </b> mysql, ingestionUtil<br><b>Tables</b> ext_table, ext_table_defb| 
|export_2_hdfs.py|The content of a hive table is stored on hdfs based on an insert overwrite hive statement|Logs errors that appear during the the interaction with hive|<b>Lirbaries </b>ingestionUtil<b><br>Tables</b>target_table|
|export_2_local.py|Exports a hive table with insert overwrite to hdfs and finally stores content on local file on the edge node. In this script colums to be exported and batch id can be specified|Logs technical errors while interacting with hive|<b> Libraries </b>ingestionUtil<br><b>Tables</b> target_table, target_table_def|
|file_hdfs.py|Either moves or deletes a file on hdfs|Logs the steps the scripts executes and a potentially an error|<b>Lirbaries </b>ingestionUtil|
|hive_2_hbase.py|Creates a Hbase table over hive based on the ext_table_definition|Technical logging of what the script does and where it fails in interacting with hive|<b><br>Tables</b> target_table, ext_table_def|
|ingestionUtil.py|A set of connect functions to (Big Data) database technologies like hive, sqoop, |Basically no logging in place here|<b>Libraries </b> jpype, jaydebeapi, impala, mysql<br><b>Environments</b> DAAS_INGEST_CONFIG, INGEST_DEBUG_MODE|
|load_2_rdbms.py|Loads a local file on the edge node into a database based on the defined meta data. This is achieved by using SQL comands like <i>Load Data</i> of MySql. It supports different vendors like Cassandra, Mysql, tera data, Oracle|Only logs the steps in the script and if the sql command was technically successful |<b> Libraries </b> ingestionUtil<br><b>Tables</b> ext_table, ext_table_def|
|publish_metadata.py|Inserts the content of a file into the metadata table. This is achieved by <i> Load Data</i> SQL command. It takes table name and path as argument| Only logs the technical steps performed as well as technicak errors|<b> Libraries </b> ingestionUtil<br>|
|purge_table.py|Drops all partitions from the hive table given as an argument|Just logs the steps the script performs| <b> Libraries </b> ingestionUtil|
|replace_2_table_jdbc.py|Transforms data in a given jdbc table and stores it in a fresh jdbc target table. The transformations are defined as part of the metadata. The transformation and data load is applied through a combinination of insert and select statements.|Only logs the technical steps the script performs as well as technicak errors|<b> Libraries </b> ingestionUtil, impala, mysql <br><b>Tables</b> ext_table, ext_table_def, target_table|
|replace_2_table.py|Same as replace_2_table_jdbc but in Hive context |Only logs the technical steps the script performs as well as technicak errors|<b> Libraries </b> ingestionUtil, impala, mysql <br><b>Tables</b> ext_table, ext_table_def, target_table|
|sqoop_2_hdfs.py|Uses sqoop to import content of a relation database into hdfs. The colums, where clause and database details are part of the meta data database|Only logs the technical steps performed|<b> Libraries </b> ingestionUtil, impala, mysql <br><b>Tables</b> ext_table <br><b> Local tools </b> sqoop|
|sqoop_2_rdbms.py|Uses sqoop to store content from a hive table into a relational database. This is based on the metadata table. In a first step the content of hive is stored in HDFS |Only logs the technical steps performed as well as technicak errors|<b> Libraries </b> ingestionUtil, impala, mysql <br><b>Tables</b> target_table, target_table_def<br><b> Local tools </b> sqoop|
|stream_2_hdfs.py|Streams a local data directory into hdfs by using spark|Logs the steps it executes and and the technical errors that occured|<b> Libraries </b> pyspark, ingestionUtil <br> <b>Variables</b> It exports hardcoded SPARK_MAJOR_VERSION<br><b>Tables</b> ext_table <br><b>Others</b> Hardcoded hdfs URL masternode.daasdev.ibm.com|
|tab_2_delim.py|takes \t and changes delimeter to what is specified in meta data table|Logs the steps it performs as well as technicak errors|<b> Libraries </b> mysql, ingestionUtil <br><b>Tables</b> ext_table|
|upsert_2_hbase.py|Inserts/Updates data from one hbase table to another|Only logs the steps performed by the script and technical errors|<b> Libraries </b> ingestionUtil <br> <b>Tables</b> ext_table, target_table|


*Node*
<i>connect_to_hbase </i> of ingestUtil is commented out. So it is currently not working.




