# DOCKER_DIP

## 1. Install Cloudera Docker Container in your machine (macos)

  - Pre-requisites: keep memory settings to 10gb or more for the cluster to run without memory porblems. Installing cloudera docker image and accessing cloudera hadoop services from your local machine are defined as below. [Jira Ticket](https://jsw.ibm.com/browse/DIPDACH-64)

  - docker pull cloudera/quickstart:latest (pull the latest cloudera docker image)
  
  - docker images (to check the downloaded image of cloudera installed on m/c)

  -  If ports of hue / any other services to be opened, mention those ports in the docker run command 
  
      - Ex1: Docker with ports of cloudera manager (7180), hue(8888), yarn(8088) opened
     ```docker run -m 4G --memory-reservation 2G --memory-swap 8G --hostname=quickstart.cloudera --privileged=true -t -i -v /Users/krishna/Desktop/projects/dip_gcloud/cloudera-docker-install:/src --publish-all=true -p 8888 -p 7180 -p 8088 cloudera/quickstart /usr/bin/docker-quickstart``` 
     
      - Ex 2: Docker with only hue port opened 
     ```docker run --hostname=quickstart.cloudera --privileged=true -t -i -v /Users/krishna/Desktop/projects/dip_gcloud/cloudera-docker-install:/src --publish-all=true -p 8888 cloudera/quickstart /usr/bin/docker-quickstart``` (moving the files to this local location /Users/krishna/Desktop/projects/dip_gcloud/cloudera-docker-install will keep the files in /src folder of docker install. No need of sftp like we do to remote machines)

  - sudo docker ps
  
  - Enter docker shell with ```docker exec -it container-id bash```
  
  - Start cloudera maanger inside docker shell with ```sudo /home/cloudera/cloudera-manager --express``` . once CM is up, restart cloudera management service, later cloudera cluster if any service is down. 
  
  - ```docker inspect container_id``` and get the hue / other service port details from netwrok settings. For example, hue port is 8088 inside docker. But outside docker (that is in our local mahicne), it is routed to http://0.0.0.0:32773/ (this can be identified within network settings of ```docker inspect container_id```)
   
  - Cloudera manager access credentials
        - username : cloudera
        - password: cloudera 
        - Once the cloudera manager is running succesfully, we see below screenshot with all services up and running
      ![screenshot](/screenshots/docker_cloudera_manager_ui.png)
        
        
  - Hue access credentials. If hue didnot start, start it in clouder manager UI or in cmd line with 
    ```service hue start```
        - username: cloudera 
        - password: cloudera    
        - we can also access hive  / impala / habse or other hadoop services in Hue web gui and submit commands from this ui as shown in below ![screenshot](/screenshots/cloudera_hue_web_ui.png)
  
  - Yarn UI as shown below
    ![screenshot](/screenshots/cloudera_yarn_ui.png)
    
Note: Incase of issues connecting to cloudera manager or other services, increase docker memeory in docker preferences. 
  
2. Upgrade centos installed in docker, install pip , ssl and other required software 
  
- In the docker container, check the default python version with ```python -version```. Follow below steps for the same. Optional: If python 2 is installed as default, setup a python virtual environment and upgrade python to python 3. 

- install ssl certificate in centos to install pip nad other software with no issues
```
yum install gcc-c++

yum install cyrus-sasl-devel.x86_64
yum install python-devel.x86_64

yum install epel-release
```
- install pip 
```
yum install python-pip (specifc to centos6. wget or curl install of get-pip.py didnt work) 
```

- Pip install necessary libraries. The order of the libraies to install mentioned below is important. Because of the dependency of one library on another. 
```
pip install sasl==0.2.1
pip install JPype1==0.6.2 (Before installing JayDeBeApi, Jpype has to be installed)
pip install JayDeBeApi==1.1.1
pip install mysql-connector-python
pip install thrift==0.9.3
pip install pyhs2
pip install thrift_sasl==0.2.1
```

3. After python upgrade, install libraries and do pip list to check if all the required libraries are installed. [Reference of library versions needed](/setup-docs/DIP_setting_on_Cloudera) or refer to complete libraries list in step 5 installation of https://github.ibm.com/digital-insights/service-batch-ingestion


4. Run DIP scripts (https://github.ibm.com/DPS-DACH/DACH_DIP/tree/master/batch-ingestion/bin) in above docker cloudera install. [Read through description of each script](/setup-docs/Documentation_DIP_Scripts.md) and install necessary packages for running that script. 
  
5. Sample DIP script run can be acheived by git pulling this repo and moving to /batch-ingestiin/bin folder and run ingestionUtil.py. The connection details in /batch-ingestion/conf/*.ini file need to be changed according to your cloudera host machine host / port details. As we have installed the docker image of cloudera in local system , we used local installation host / port details. If the hadoop cluster is installed in a cloud enviironment as mentioned in https://github.ibm.com/DPS-DACH/DACH_DIP/blob/master/batch-ingestion/conf/ingestion_config.ini, we need to change the details to cloud host / port. 


